var Te=Object.defineProperty;var Se=(a,t,e)=>t in a?Te(a,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):a[t]=e;var E=(a,t,e)=>Se(a,typeof t!="symbol"?t+"":t,e);import{i as he,S as me}from"./domain_rules-CwjSZosE.js";const ve="madadgar-sidepanel";class se{static getConnectedPorts(){return Array.from(this.connectedPorts)}static registerPort(t){t.name===ve&&(this.connectedPorts.add(t),console.log(`[MessageBus] Side Panel port connected (Total: ${this.connectedPorts.size})`),t.onDisconnect.addListener(()=>{this.connectedPorts.delete(t),console.log(`[MessageBus] Side Panel port disconnected (Remaining: ${this.connectedPorts.size})`)}),t.onMessage.addListener(e=>{this.handlePortMessage(t,e).catch(i=>{console.error("[MessageBus] Error handling port message:",i)})}))}static broadcast(t){for(const e of this.connectedPorts)try{e.postMessage(t)}catch(i){console.warn("[MessageBus] Failed to post message to port, deleting dead port:",i),this.connectedPorts.delete(e)}}static async getPageContext(t,e=!1){let i=t,r=null;if(typeof chrome<"u"&&chrome.tabs){if(typeof i=="number")try{r=await chrome.tabs.get(i)}catch{}r||(r=(await chrome.tabs.query({active:!0,currentWindow:!0}))[0]||null,i=r==null?void 0:r.id)}if(!r||typeof i!="number")return{tabId:-1,title:"No Active Tab",url:"",textContent:"",length:0,timestamp:Date.now()};if(!e&&this.contextCache.has(i))return this.contextCache.get(i);const n=r.url||"",o=r.title||"Untitled Page",s=r.favIconUrl;if(n.startsWith("chrome://")||n.startsWith("chrome-extension://")||n.startsWith("edge://")||n.startsWith("about:")){const g={tabId:i,title:o,url:n,favIconUrl:s,textContent:"",length:0,timestamp:Date.now()};return this.contextCache.set(i,g),g}let l=null;try{l=await new Promise(g=>{chrome.tabs.sendMessage(i,{type:"EXTRACT_READABILITY_CONTENT"},u=>{chrome.runtime.lastError?g(null):g(u)})})}catch{l=null}const c=(l==null?void 0:l.textContent)||"",m={tabId:i,title:(l==null?void 0:l.title)||o,url:n,favIconUrl:s,selection:l==null?void 0:l.selection,textContent:c,byline:(l==null?void 0:l.byline)||null,length:c.length,isYouTube:l==null?void 0:l.isYouTube,youTubeData:l==null?void 0:l.youTubeData,timestamp:Date.now()};return this.contextCache.set(i,m),m}static async handlePortMessage(t,e){if(!(!e||!e.type))switch(e.type){case"GET_PAGE_CONTEXT":{const i=e;try{const r=await this.getPageContext(i.tabId,i.forceRefresh),n={type:"PAGE_CONTEXT_RESULT",requestId:i.requestId,context:r};t.postMessage(n)}catch(r){const n=r instanceof Error?r.message:String(r),o={type:"PAGE_CONTEXT_RESULT",requestId:i.requestId,context:null,error:n};t.postMessage(o)}break}case"SYNC_PAGE_CONTEXT":{try{const i=await this.getPageContext(void 0,!0),r={type:"PAGE_CONTEXT_RESULT",requestId:e.requestId,context:i};t.postMessage(r)}catch(i){const r=i instanceof Error?i.message:String(i);t.postMessage({type:"PAGE_CONTEXT_RESULT",requestId:e.requestId,context:null,error:r})}break}case"PING":{t.postMessage({type:"PONG",requestId:e.requestId});break}default:console.warn("[MessageBus] Unhandled port message type:",e.type)}}static handleTabActivated(t){console.log(`[MessageBus] Tab activated: ${t.tabId}`);const e={type:"TAB_CHANGED",tabId:t.tabId,windowId:t.windowId};this.broadcast(e)}static handleTabUpdated(t,e,i){if((e.status==="loading"||e.url)&&this.contextCache.delete(t),e.status==="complete"||e.url){console.log(`[MessageBus] Tab updated: ${t} (${i.url})`);const r={type:"TAB_UPDATED",tabId:t,url:i.url,title:i.title,status:e.status};this.broadcast(r)}}static init(){var t,e,i,r;typeof chrome>"u"||((t=chrome.runtime)!=null&&t.onConnect&&chrome.runtime.onConnect.addListener(n=>{this.registerPort(n)}),(e=chrome.tabs)!=null&&e.onActivated&&chrome.tabs.onActivated.addListener(n=>{this.handleTabActivated(n)}),(i=chrome.tabs)!=null&&i.onUpdated&&chrome.tabs.onUpdated.addListener((n,o,s)=>{this.handleTabUpdated(n,o,s)}),(r=chrome.runtime)!=null&&r.onMessage&&chrome.runtime.onMessage.addListener((n,o,s)=>(n==null?void 0:n.type)==="GET_PAGE_CONTEXT"?(this.getPageContext(n.tabId,n.forceRefresh).then(l=>s({context:l})).catch(l=>s({error:String(l)})),!0):!1),console.log("[MessageBus] Initialized background port and tab listeners"))}}E(se,"connectedPorts",new Set),E(se,"contextCache",new Map);const y={GEMINI_API_KEY:"gemini_api_key",GROQ_API_KEY:"groq_api_key",PREFERRED_LANGUAGE:"preferred_language",SETTINGS:"settings",PROFILE_MEMORY:"profile_memory",SAVED_SKILLS:"saved_skills",AUDIT_LOGS:"audit_logs",ACTIVE_TASK_SESSION:"active_task_session"},Ie="en",T={personal:{fullName:"",email:"",phone:"",location:""},academic:{institution:"",degree:"",major:"",graduationYear:""},professional:{skills:[],linkedInUrl:"",githubUrl:"",portfolioUrl:""},preferences:{defaultLanguage:"en",tone:"formal"}},Fe={personal:{fullName:"Aarav Sharma",email:"aarav.sharma@example.com",phone:"+91 98765 43210",location:"Bengaluru, Karnataka, India"},academic:{institution:"National Institute of Technology",degree:"Bachelor of Technology (B.Tech)",major:"Computer Science & Engineering",graduationYear:"2025"},professional:{skills:["TypeScript","React","Node.js","Python","Tailwind CSS","Git"],linkedInUrl:"https://linkedin.com/in/aarav-sharma",githubUrl:"https://github.com/aarav-sharma",portfolioUrl:"https://aaravsharma.dev"},preferences:{defaultLanguage:"hinglish",tone:"formal"}},J=[{id:"skill-exam-notes",name:"Exam Notes",title:"Exam Notes",description:"Generates structured revision notes with core formulas, definitions, key concepts, and exam questions from the active page.",category:"study",tags:["Study","Revision","Formulas","Student"],promptTemplate:`Analyze the current page content and generate structured, comprehensive Exam Revision Notes:
1. Core Definitions & Formulas (with short explanations)
2. Key Concepts & Principles (broken down simply)
3. Top 3 High-Yield Exam Questions with ideal concise answers
4. Rapid-Recall Mnemonics / Bullet Summary`,targetTab:"chat",isBuiltIn:!0,version:"1.0.0",createdAt:17e11},{id:"skill-explain-hinglish",name:"Explain in Hinglish",title:"Explain in Hinglish",description:"Translates and breaks down complex concepts into conversational, easy-to-understand Hindi written in Roman script (Hinglish).",category:"study",tags:["Bilingual","Hinglish","Translation","Simplified"],promptTemplate:"Is page ke content ko simple aur conversational Hinglish (colloquial Hindi written in Roman script) mein samjhaiye. Daily life ke practical examples use karein, technical words English mein rakhein, aur 5 crisp points mein main concept clear karein.",targetTab:"chat",isBuiltIn:!0,version:"1.0.0",createdAt:17e11},{id:"skill-reply-email-politely",name:"Reply to this email politely",title:"Reply to this email politely",description:"Drafts a courteous, well-structured professional reply acknowledging all details with actionable next steps.",category:"writing",tags:["Email","Professional","Polite","Draft"],promptTemplate:`Based on the email/message content on this active tab, draft a polite, clear, and professional response:
1. Warm acknowledgment & thank you
2. Direct responses to any questions or requests
3. Clear, proposed next steps with timeline
4. Professional sign-off`,targetTab:"chat",isBuiltIn:!0,version:"1.0.0",createdAt:17e11},{id:"skill-fill-form-profile",name:"Fill form from my profile",title:"Fill form from my profile",description:"Automatically inspects interactive form fields on the active page and proposes sequential autofill values mapped from your saved profile.",category:"forms",tags:["Autofill","Profile","Internship","HITL"],requiresProfile:!0,promptTemplate:"Fill all interactive form inputs on this page using my local saved profile details (name, email, phone, location, college/university, degree, major, graduation year, skills, LinkedIn, GitHub, portfolio). Inspect each field, map matching profile fields, and propose each fill step for my approval.",targetTab:"agent",isBuiltIn:!0,version:"1.0.0",createdAt:17e11}],ge="https://generativelanguage.googleapis.com/v1beta",pe="https://api.groq.com/openai/v1",fe="gemini-2.5-flash-lite",oe="gemini-2.5-flash",ye=["gemini-2.5-flash-lite","gemini-3.5-flash-lite","gemini-flash-lite-latest","gemini-3.1-flash-lite"],Q="llama-3.3-70b-versatile",we={GEMINI_API_KEY:"AQ.Ab8RN6J2hTOQt7PSKX8t1XxWwDBpoGMlRS-0C8YlnIqQt6yO9A",GROK_API_KEY:"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"},ae=new Map,ie=()=>{var a;return typeof chrome<"u"&&!!((a=chrome.storage)!=null&&a.local)};async function M(a){return ie()?new Promise((t,e)=>{chrome.storage.local.get([a],i=>{if(chrome.runtime.lastError)return e(new Error(chrome.runtime.lastError.message));t(i[a])})}):ae.get(a)}async function S(a,t){if(ie())return new Promise((e,i)=>{chrome.storage.local.set({[a]:t},()=>{if(chrome.runtime.lastError)return i(new Error(chrome.runtime.lastError.message));e()})});ae.set(a,t)}async function _e(a){if(ie())return new Promise((t,e)=>{chrome.storage.local.remove([a],()=>{if(chrome.runtime.lastError)return e(new Error(chrome.runtime.lastError.message));t()})});ae.delete(a)}function xe(){const a=typeof import.meta<"u"?we:void 0;if(a){if(a.GEMINI_API_KEY)return a.GEMINI_API_KEY;if(a.VITE_GEMINI_API_KEY)return a.VITE_GEMINI_API_KEY}}function Le(){const a=typeof import.meta<"u"?we:void 0;if(a){if(a.GROQ_API_KEY)return a.GROQ_API_KEY;if(a.GROK_API_KEY)return a.GROK_API_KEY;if(a.VITE_GROQ_API_KEY)return a.VITE_GROQ_API_KEY;if(a.VITE_GROK_API_KEY)return a.VITE_GROK_API_KEY}}async function B(a){const[e,i,r,n]=await Promise.all([M(y.SETTINGS),M(y.GEMINI_API_KEY),M(y.GROQ_API_KEY),M(y.PREFERRED_LANGUAGE)]),o=(e==null?void 0:e.geminiApiKey)||i||xe()||"",s=(e==null?void 0:e.groqApiKey)||r||Le()||"",l=(e==null?void 0:e.defaultLanguage)||n||Ie;return{geminiApiKey:o,groqApiKey:s,defaultLanguage:l}}async function Ve(a){await Promise.all([S(y.SETTINGS,a),S(y.GEMINI_API_KEY,a.geminiApiKey),S(y.GROQ_API_KEY,a.groqApiKey||""),S(y.PREFERRED_LANGUAGE,a.defaultLanguage)])}async function We(a){await S(y.ACTIVE_TASK_SESSION,a)}async function ze(){return await M(y.ACTIVE_TASK_SESSION)||null}async function Je(){await _e(y.ACTIVE_TASK_SESSION)}async function ke(){const a=await M(y.AUDIT_LOGS);return Array.isArray(a)?a:[]}async function Qe(a){const t={...a,id:`audit-${Date.now()}-${Math.random().toString(36).substring(2,7)}`,timestamp:Date.now()},e=await ke(),i=[t,...e].slice(0,200);return await S(y.AUDIT_LOGS,i),t}async function Xe(){await S(y.AUDIT_LOGS,[])}async function Ze(){const a=await ke();return JSON.stringify(a,null,2)}async function Ne(){var t,e,i;const a=await M(y.PROFILE_MEMORY);return a?{personal:{...T.personal,...a.personal},academic:{...T.academic,...a.academic,institution:((t=a.academic)==null?void 0:t.institution)||((e=a.academic)==null?void 0:e.college)||""},professional:{...T.professional,...a.professional,skills:Array.isArray((i=a.professional)==null?void 0:i.skills)?[...a.professional.skills]:[]},preferences:{...T.preferences,...a.preferences}}:{personal:{...T.personal},academic:{...T.academic},professional:{...T.professional,skills:[...T.professional.skills]},preferences:{...T.preferences}}}async function Ce(a){await S(y.PROFILE_MEMORY,a)}async function et(){await S(y.PROFILE_MEMORY,{personal:{...T.personal},academic:{...T.academic},professional:{...T.professional,skills:[...T.professional.skills]},preferences:{...T.preferences}})}async function tt(){const a=await Ne();return JSON.stringify(a,null,2)}async function at(a){var t,e,i,r,n,o,s,l,c,m,g,u,d,f,p,w;try{const h=JSON.parse(a);if(!h||typeof h!="object")throw new Error("Invalid JSON format for user profile.");const b={personal:{fullName:String(((t=h.personal)==null?void 0:t.fullName)||""),email:String(((e=h.personal)==null?void 0:e.email)||""),phone:String(((i=h.personal)==null?void 0:i.phone)||""),location:String(((r=h.personal)==null?void 0:r.location)||"")},academic:{institution:String(((n=h.academic)==null?void 0:n.institution)||((o=h.academic)==null?void 0:o.college)||""),degree:String(((s=h.academic)==null?void 0:s.degree)||""),major:String(((l=h.academic)==null?void 0:l.major)||""),graduationYear:String(((c=h.academic)==null?void 0:c.graduationYear)||"")},professional:{skills:Array.isArray((m=h.professional)==null?void 0:m.skills)?h.professional.skills.map(v=>String(v).trim()).filter(Boolean):typeof((g=h.professional)==null?void 0:g.skills)=="string"?h.professional.skills.split(",").map(v=>v.trim()).filter(Boolean):[],linkedInUrl:String(((u=h.professional)==null?void 0:u.linkedInUrl)||""),githubUrl:String(((d=h.professional)==null?void 0:d.githubUrl)||""),portfolioUrl:String(((f=h.professional)==null?void 0:f.portfolioUrl)||"")},preferences:{defaultLanguage:((p=h.preferences)==null?void 0:p.defaultLanguage)==="hinglish"?"hinglish":"en",tone:["formal","casual","academic"].includes((w=h.preferences)==null?void 0:w.tone)?h.preferences.tone:"formal"}};return await Ce(b),b}catch(h){throw new Error(`Failed to import profile: ${(h==null?void 0:h.message)||"Invalid format"}`)}}async function X(){const a=await M(y.SAVED_SKILLS);return!a||!Array.isArray(a)||a.length===0?(await S(y.SAVED_SKILLS,[...J]),[...J]):a}async function it(a){const t=await X(),e=a.id||`skill_custom_${Date.now()}_${Math.random().toString(36).slice(2,6)}`,i=a.createdAt||Date.now(),r={...a,id:e,name:a.name||a.title||"Untitled Skill",title:a.title||a.name||"Untitled Skill",description:a.description||"",promptTemplate:a.promptTemplate||a.userPromptTemplate||"",category:a.category||"custom",tags:Array.isArray(a.tags)?a.tags:[],requiresProfile:!!a.requiresProfile,targetTab:a.targetTab||(a.category==="forms"||a.category==="form"?"agent":"chat"),createdAt:i,version:a.version||"1.0.0",isBuiltIn:!!a.isBuiltIn},n=t.findIndex(s=>s.id===e);let o;return n>=0?(o=[...t],o[n]=r):o=[r,...t],await S(y.SAVED_SKILLS,o),r}async function rt(a){const e=(await X()).filter(i=>i.id!==a);await S(y.SAVED_SKILLS,e)}async function nt(){return await S(y.SAVED_SKILLS,[...J]),[...J]}async function st(){const a=await X();return JSON.stringify(a,null,2)}async function ot(a){try{const t=JSON.parse(a),e=Array.isArray(t)?t:[t];if(e.length===0)throw new Error("Skills file contains no valid skills.");const i=[];for(const s of e){if(!s||typeof s!="object")continue;const l=String(s.name||s.title||"").trim(),c=String(s.promptTemplate||s.userPromptTemplate||"").trim();if(!l||!c)throw new Error("Imported skills must contain at least a name/title and promptTemplate.");const m=String(s.id||`skill_imported_${Date.now()}_${Math.random().toString(36).slice(2,6)}`);i.push({id:m,name:l,title:l,description:String(s.description||""),promptTemplate:c,category:["study","writing","forms","custom","summary","reply","form"].includes(s.category)?s.category:"custom",tags:Array.isArray(s.tags)?s.tags.map(g=>String(g).trim()).filter(Boolean):typeof s.tags=="string"?s.tags.split(",").map(g=>g.trim()).filter(Boolean):[],requiresProfile:!!s.requiresProfile,targetTab:s.targetTab==="agent"||s.category==="forms"||s.category==="form"?"agent":"chat",version:String(s.version||"1.0.0"),isBuiltIn:!!s.isBuiltIn,createdAt:typeof s.createdAt=="number"?s.createdAt:Date.now()})}const r=await X(),n=new Map(r.map(s=>[s.id,s]));for(const s of i)n.set(s.id,s);const o=Array.from(n.values());return await S(y.SAVED_SKILLS,o),o}catch(t){throw new Error(`Failed to import skills: ${(t==null?void 0:t.message)||"Invalid JSON format"}`)}}class _ extends Error{constructor(e,i,r,n){super(e);E(this,"status");E(this,"statusText");E(this,"details");this.name="GeminiApiError",this.status=i,this.statusText=r,this.details=n}get isRateLimited(){return this.status===429}get isModelUnavailable(){return this.status===404}}function Ae(a,t,e){const r={contents:Array.isArray(a)?a:[{role:"user",parts:[{text:a}]}],generationConfig:{temperature:(e==null?void 0:e.temperature)??.2,maxOutputTokens:(e==null?void 0:e.maxOutputTokens)??2048,...(e==null?void 0:e.topP)!==void 0?{topP:e.topP}:{},...(e==null?void 0:e.topK)!==void 0?{topK:e.topK}:{},...e!=null&&e.stopSequences?{stopSequences:e.stopSequences}:{}}};return t&&(r.systemInstruction={parts:[{text:t}]}),r}async function O(a){var c,m,g,u,d;const{apiKey:t,prompt:e,systemInstruction:i,config:r,signal:n}=a,o=a.model||fe,s=[o,...ye.filter(f=>f!==o)];let l=null;for(const f of s)try{const p=`${ge}/models/${f}:generateContent?key=${encodeURIComponent(t)}`,w=Ae(e,i,r),h=await fetch(p,{method:"POST",headers:{"Content-Type":"application/json",Accept:"application/json"},body:JSON.stringify(w),signal:n});if(!h.ok){const k=await h.json().catch(()=>null),A=((c=k==null?void 0:k.error)==null?void 0:c.message)||`HTTP ${h.status}: ${h.statusText}`;if(h.status===404&&s.indexOf(f)<s.length-1){l=new _(A,h.status,h.statusText,k);continue}throw new _(A,h.status,h.statusText,k)}const b=await h.json(),v=(m=b.candidates)==null?void 0:m[0],P=(d=(u=(g=v==null?void 0:v.content)==null?void 0:g.parts)==null?void 0:u[0])==null?void 0:d.text;if(typeof P!="string")throw new _("Invalid or empty response format from Gemini API",500,"Empty response",b);return P}catch(p){if(p instanceof _&&p.status===404&&s.indexOf(f)<s.length-1){l=p;continue}throw p}throw l||new _("All candidate Gemini models failed",500,"Model error")}async function G(a){var m,g,u,d,f,p,w,h,b,v,P;const{apiKey:t,prompt:e,systemInstruction:i,config:r,signal:n,onChunk:o}=a,s=a.model||fe,l=[s,...ye.filter(k=>k!==s)];let c=null;for(const k of l)try{const A=`${ge}/models/${k}:streamGenerateContent?alt=sse&key=${encodeURIComponent(t)}`,R=Ae(e,i,r),I=await fetch(A,{method:"POST",headers:{"Content-Type":"application/json",Accept:"text/event-stream"},body:JSON.stringify(R),signal:n});if(!I.ok){const C=await I.json().catch(()=>null),q=((m=C==null?void 0:C.error)==null?void 0:m.message)||`HTTP ${I.status}: ${I.statusText}`;if(I.status===404&&l.indexOf(k)<l.length-1){c=new _(q,I.status,I.statusText,C);continue}throw new _(q,I.status,I.statusText,C)}if(!I.body)throw new _("Response body is null, streaming not supported in this runtime",500,"No stream");const Y=I.body.getReader(),j=new TextDecoder("utf-8");let L="",N="";for(;;){const{value:C,done:q}=await Y.read();if(q)break;N+=j.decode(C,{stream:!0});const $=N.split(`
`);N=$.pop()||"";for(const Ee of $){const re=Ee.trim();if(re.startsWith("data: ")){const ne=re.slice(6).trim();if(ne==="[DONE]")continue;try{const Z=(p=(f=(d=(u=(g=JSON.parse(ne).candidates)==null?void 0:g[0])==null?void 0:u.content)==null?void 0:d.parts)==null?void 0:f[0])==null?void 0:p.text;Z&&(L+=Z,o&&o(Z,L))}catch{}}}}if(N.trim().startsWith("data: "))try{const C=N.trim().slice(6).trim(),$=(P=(v=(b=(h=(w=JSON.parse(C).candidates)==null?void 0:w[0])==null?void 0:h.content)==null?void 0:b.parts)==null?void 0:v[0])==null?void 0:P.text;$&&(L+=$,o&&o($,L))}catch{}return L}catch(A){if(A instanceof _&&A.status===404&&l.indexOf(k)<l.length-1){c=A;continue}throw A}throw c||new _("All streaming candidate Gemini models failed",500,"Model error")}class D extends Error{constructor(e,i,r,n){super(e);E(this,"status");E(this,"statusText");E(this,"details");this.name="GroqApiError",this.status=i,this.statusText=r,this.details=n}get isRateLimited(){return this.status===429}}function x(a,t){const e=[];if(t&&t.trim()&&e.push({role:"system",content:t.trim()}),typeof a=="string")return e.push({role:"user",content:a}),e;if(Array.isArray(a))for(const i of a){const r=i.role==="model"?"assistant":"user",n=i.parts.map(o=>o.text||"").filter(Boolean).join(`
`).trim();n&&e.push({role:r,content:n})}return(e.length===0||!e.some(i=>i.role==="user"))&&e.push({role:"user",content:"Hello"}),e}async function K(a){var g,u,d,f;const{apiKey:t,messages:e,model:i=Q,temperature:r=.3,maxTokens:n=4096,signal:o}=a,s=`${pe}/chat/completions`,l=await fetch(s,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t.trim()}`,Accept:"application/json"},body:JSON.stringify({model:i,messages:e,temperature:r,max_tokens:n,stream:!1}),signal:o});if(!l.ok){const p=await l.json().catch(()=>null),w=((g=p==null?void 0:p.error)==null?void 0:g.message)||`Groq HTTP ${l.status}: ${l.statusText}`;throw new D(w,l.status,l.statusText,p)}const c=await l.json(),m=(f=(d=(u=c==null?void 0:c.choices)==null?void 0:u[0])==null?void 0:d.message)==null?void 0:f.content;if(typeof m!="string")throw new D("Empty response content received from Groq API",500,"Invalid response");return m}async function H(a){var f,p,w,h,b,v,P;const{apiKey:t,messages:e,model:i=Q,temperature:r=.3,maxTokens:n=4096,signal:o,onChunk:s}=a,l=`${pe}/chat/completions`,c=await fetch(l,{method:"POST",headers:{"Content-Type":"application/json",Authorization:`Bearer ${t.trim()}`,Accept:"text/event-stream"},body:JSON.stringify({model:i,messages:e,temperature:r,max_tokens:n,stream:!0}),signal:o});if(!c.ok){const k=await c.json().catch(()=>null),A=((f=k==null?void 0:k.error)==null?void 0:f.message)||`Groq HTTP ${c.status}: ${c.statusText}`;throw new D(A,c.status,c.statusText,k)}if(!c.body)throw new D("Response body is null, streaming not supported",500,"No stream");const m=c.body.getReader(),g=new TextDecoder("utf-8");let u="",d="";for(;;){const{value:k,done:A}=await m.read();if(A)break;d+=g.decode(k,{stream:!0});const R=d.split(`
`);d=R.pop()||"";for(const I of R){const Y=I.trim();if(Y.startsWith("data: ")){const j=Y.slice(6).trim();if(j==="[DONE]")continue;try{const L=JSON.parse(j),N=(h=(w=(p=L==null?void 0:L.choices)==null?void 0:p[0])==null?void 0:w.delta)==null?void 0:h.content;N&&(u+=N,s&&s(N,u))}catch{}}}}if(d.trim().startsWith("data: ")){const k=d.trim().slice(6).trim();if(k!=="[DONE]")try{const A=JSON.parse(k),R=(P=(v=(b=A==null?void 0:A.choices)==null?void 0:b[0])==null?void 0:v.delta)==null?void 0:P.content;R&&(u+=R,s&&s(R,u))}catch{}}return u}const be={en:`You are Madadgar, an expert reading assistant. Your task is to analyze the provided article or text and generate a concise, high-value structured summary.

CRITICAL INSTRUCTIONS:
You MUST format your output strictly into the following three sections using exact Markdown headers:

### 📌 TL;DR
[A single, crisp, high-impact one-sentence summary capturing the core premise.]

### 💡 5 Key Takeaways
1. [First crucial takeaway or insight]
2. [Second crucial takeaway with supporting evidence or data]
3. [Third crucial takeaway highlighting key reasoning]
4. [Fourth crucial takeaway explaining context or nuance]
5. [Fifth crucial takeaway on outcome or conclusion]

### 🚀 Actionable Next Steps
- [Concrete action item or takeaway for the reader]
- [Next step, relevant tool, or application to explore]
- [Key decision point or critical follow-up]

RULES:
- Provide EXACTLY 5 key takeaways.
- Keep the TL;DR to ONE sentence only.
- Write in clear, professional English.
- Ground your summary strictly in the provided text. Do not hallucinate external facts.`,hinglish:`You are Madadgar, an expert bilingual reading assistant. Your task is to analyze the provided article or text and generate a conversational structured summary in colloquial Hinglish (Hindi written in Roman script, naturally blended with English technical terminology).

CRITICAL INSTRUCTIONS:
Explain in colloquial, conversational Hindi written in Roman script (Hinglish), mixing natural Hindi phrasing with English technical terms.
You MUST format your output strictly into the following three sections using exact Markdown headers:

### 📌 TL;DR
[Sirf ek crisp aur clear line me poore article ka core essence ya mukhya baat.]

### 💡 5 Key Takeaways
1. [Pehli sabse important point ya learning]
2. [Doosra zaroori takeaway context ya logic ke saath]
3. [Teesra key point jo article highlight karta hai]
4. [Chautha important detail ya fact]
5. [Paanchva conclusion ya main takeaway]

### 🚀 Actionable Next Steps
- [Aapko aage kya karna chahiye ya dhyan me rakhna chahiye]
- [Practical application ya next action item]
- [Follow-up step ya practice point]

RULES:
- Exactly 5 key takeaways hone chahiye.
- TL;DR sirf EK single sentence me ho.
- Tone friendly, relatable aur natural Hinglish me ho (e.g., "Yeh article explain karta hai ki...", "Dhyan dene wali baat yeh hai...").
- Text ke bahar ki koi fabricated baatein na likhein.`};function le(a,t){const e=(t==null?void 0:t.language)==="hinglish"?"hinglish":"en",i=be[e],r=[];t!=null&&t.title&&r.push(`Title: "${t.title}"`),t!=null&&t.author&&r.push(`Author: ${t.author}`),t!=null&&t.url&&r.push(`Source URL: ${t.url}`);const o=`${r.length>0?`METADATA:
${r.join(`
`)}

`:""}ARTICLE CONTENT TO SUMMARIZE:
"""
${a.trim()}
"""

Please provide the structured summary following the 3 required sections strictly.`;return{systemInstruction:i,userPrompt:o}}const Pe={en:`You are Madadgar, an expert video reading assistant. Your task is to analyze the provided YouTube video transcript and generate a structured chapter-style summary with timestamped highlights.

CRITICAL INSTRUCTIONS:
You MUST format your output strictly into the following three sections using exact Markdown headers:

### 📌 TL;DR
[A single, crisp, high-impact one-sentence summary capturing the core premise of the video.]

### 💡 5 Key Takeaways
1. [mm:ss] **[Chapter / Topic Name]**: [Concise explanation of this section's core takeaway]
2. [mm:ss] **[Chapter / Topic Name]**: [Concise explanation of this section's core takeaway]
3. [mm:ss] **[Chapter / Topic Name]**: [Concise explanation of this section's core takeaway]
4. [mm:ss] **[Chapter / Topic Name]**: [Concise explanation of this section's core takeaway]
5. [mm:ss] **[Chapter / Topic Name]**: [Concise explanation of this section's core takeaway]

### 🚀 Actionable Next Steps
- [Concrete action item or takeaway for the viewer]
- [Next step, relevant tool, or technique to explore]
- [Key decision point or follow-up practice]

RULES:
- YouTube Transcript Rule: Always cite the relevant timestamp [mm:ss] at the beginning of each of the 5 takeaways.
- Provide EXACTLY 5 key takeaways.
- Keep the TL;DR to ONE sentence only.
- Write in clear, professional English.
- Ground your summary strictly in the provided transcript. Do not hallucinate external facts.`,hinglish:`You are Madadgar, an expert bilingual video assistant. Your task is to analyze the provided YouTube transcript and generate a chapter-style structured summary in colloquial Hinglish (Hindi written in Roman script, naturally blended with English technical terminology).

CRITICAL INSTRUCTIONS:
Explain in colloquial, conversational Hindi written in Roman script (Hinglish), mixing natural Hindi phrasing with English technical terms.
You MUST format your output strictly into the following three sections using exact Markdown headers:

### 📌 TL;DR
[Sirf ek crisp aur clear line me poore video ka core essence ya mukhya message.]

### 💡 5 Key Takeaways
1. [mm:ss] **[Chapter / Topic Name]**: [Pehla zaroori point timestamp ke saath explain karein]
2. [mm:ss] **[Chapter / Topic Name]**: [Doosra key topic explanation ke saath]
3. [mm:ss] **[Chapter / Topic Name]**: [Teesra takeaway aur uski details]
4. [mm:ss] **[Chapter / Topic Name]**: [Chautha important learning point]
5. [mm:ss] **[Chapter / Topic Name]**: [Paanchva conclusion ya final takeaway]

### 🚀 Actionable Next Steps
- [Aapko aage kya karna chahiye ya try karna chahiye]
- [Practical application ya next action item]
- [Follow-up step ya resource jo explore karni hai]

RULES:
- Har ek key takeaway ke shuru me timestamp [mm:ss] zaroor likhein.
- Exactly 5 key takeaways hone chahiye.
- TL;DR sirf EK single sentence me ho.
- Tone friendly, relatable aur natural Hinglish me ho.`};function ce(a,t){const e=(t==null?void 0:t.language)==="hinglish"?"hinglish":"en",i=(t==null?void 0:t.hasTranscript)!==!1&&a.trim().length>0;let r=Pe[e];if(!i){const c=e==="hinglish"?`

NOTE: Is video me captions/transcripts disabled hain. Creator ke description aur metadata ke aadhar par structured overview provide karein.`:`

NOTE: Captions are disabled on this video. Provide an overview based on the creator's description and metadata.`;r=be[e]+c}const n=[];t!=null&&t.title&&n.push(`Video Title: "${t.title}"`),(t!=null&&t.channelTitle||t!=null&&t.author)&&n.push(`Channel: ${(t==null?void 0:t.channelTitle)||(t==null?void 0:t.author)}`),t!=null&&t.videoId&&n.push(`Video ID: ${t.videoId}`),t!=null&&t.url&&n.push(`Video URL: ${t.url}`);const o=n.length>0?`METADATA:
${n.join(`
`)}

`:"";let s="";i?s=`TIMESTAMPED TRANSCRIPT:
"""
${a.trim()}
"""`:s=`VIDEO DESCRIPTION & METADATA (Captions Disabled):
"""
${((t==null?void 0:t.description)||a||"No description provided.").trim()}
"""`;const l=`${o}${s}

Please provide the structured chapter summary following the 3 required sections strictly.`;return{systemInstruction:r,userPrompt:l}}function F(a){const t=a.trim();let e="";const i=[],r=[],n=t.match(/###?\s*📌?\s*TL;?DR[:\s]*\n+([\s\S]*?)(?=\n+###?|\n*$)/i);n&&(e=n[1].trim().replace(/^\[|\]$/g,"").trim());const o=t.match(/###?\s*💡?\s*5?\s*Key Takeaways[:\s]*\n+([\s\S]*?)(?=\n+###?|\n*$)/i);if(o){const c=o[1].trim().split(`
`);for(const m of c){const u=m.trim().replace(/^\d+[\.\)]\s*|^[-*•]\s*/,"").trim();u.length>0&&i.push(u)}}const s=t.match(/###?\s*🚀?\s*Actionable (?:Next Steps|Items)[:\s]*\n+([\s\S]*?)(?=\n+###?|\n*$)/i);if(s){const c=s[1].trim().split(`
`);for(const m of c){const u=m.trim().replace(/^[-*•]\s*|^\d+[\.\)]\s*/,"").trim();u.length>0&&r.push(u)}}return{tldr:e,keyTakeaways:i,actionableSteps:r,rawText:t}}const ue={en:`You are Madadgar, an expert browser AI assistant grounded strictly in the current webpage context provided below.

CRITICAL GROUNDING RULES:
1. Answer questions STRICTLY and EXCLUSIVELY based on the provided page context.
2. If the user's query asks for information that is NOT mentioned or directly inferable from the page context, you MUST explicitly state:
"This information is not present on the current page."
Do NOT invent external facts, assume outside details, or bring in outside knowledge.
3. If the user asks about a specific section or topic that exists on the page, quote or cite the relevant part directly.
4. If a user highlighted or selected specific text on the page, prioritize answering in relation to that selected excerpt.
5. Format your response cleanly using Markdown (bullet points, bold text, code blocks where appropriate).
6. Be concise, direct, and factual.`,hinglish:`You are Madadgar, an expert bilingual browser assistant grounded strictly in the current webpage context provided below.

CRITICAL GROUNDING RULES:
1. Aapko diye gaye webpage context ke aadhar par hi sawaal ka jawaab dena hai.
2. Agar poochhi gayi information page par maujood NAHI hai, to saaf shabdon me kahein:
"This information is not present on the current page." (Ya "Yeh information is page par maujood nahi hai.")
Text ke bahar ki koi fabricated baatein na likhein.
3. Conversational, colloquial Hinglish me baat karein (Hindi written in Roman script, naturally blended with English technical terminology).
4. Agar user ne page par koi specific text select kiya hai, to us context ko dhyan me rakhkar jawaab dein.
5. Saaf Markdown formatting use karein (bullet points, bold text).
6. Direct aur accurate rahein.`},V={en:`You are Madadgar, an intelligent browser AI assistant connected directly to a full-capability Large Language Model (LLM).

GENERAL INTELLIGENCE & FLEXIBILITY:
1. You can answer ANY question the user asks—whether it directly relates to the current page or is completely external/general knowledge (e.g. general explanations, science, coding, math, history, everyday questions, translations, creative writing).
2. If webpage context is provided below, seamlessly use it to inform your answer whenever the question pertains to the page or references it.
3. If the user's question asks for information NOT present on the page or is unrelated to the page, DO NOT refuse or say it is missing. Instead, use your full LLM intelligence and general knowledge to provide an insightful, accurate, and comprehensive answer!
4. If the user highlighted or selected specific text on the page, prioritize answering in relation to that selected excerpt while drawing upon outside knowledge where helpful.
5. Format your response cleanly using Markdown (bullet points, bold text, code blocks where appropriate).
6. Be concise, direct, helpful, and polite.`,hinglish:`You are Madadgar, an intelligent bilingual browser AI assistant connected directly to a full-capability Large Language Model (LLM).

GENERAL INTELLIGENCE & FLEXIBILITY:
1. Aapke paas full general knowledge aur webpage context dono ka access hai. User kisi bhi topic par sawaal pooch sakta hai.
2. Agar sawaal current page se related hai, toh page context aur selected text ka use karke badhiya aur accurate jawaab dein.
3. Agar poochhi gayi information page par maujood NAHI hai ya sawaal page se bilkul alag hai (general knowledge, coding, explanations), toh sawaal reject mat karein. Apni full general intelligence se pura, helpful aur accurate jawaab dein!
4. Conversational, colloquial Hinglish me baat karein (Hindi written in Roman script, naturally blended with English technical terminology).
5. Agar user ne koi specific text select kiya hai, toh us context ko dhyan me rakhkar jawaab dein.
6. Saaf Markdown formatting use karein (bullet points, bold text, code blocks).
7. Direct, helpful aur accurate rahein.`};function Re(a,t="en",e="grounded"){if(a!=null&&a.url&&he(a.url))return e==="llm"?`${V[t]||V.en}

[SECURITY NOTICE: Active tab is on a protected financial/banking domain. Page context is strictly excluded for user security.]`:`You are Madadgar.
SECURITY POLICY: ${me}
Strictly refuse interaction with this page context.`;if(e==="llm"){const i=V[t]||V.en;if(!a||!a.textContent&&!a.selection&&!a.title)return i;const r=[];a.title&&r.push(`Page Title: "${a.title}"`),a.url&&r.push(`Page URL: ${a.url}`),a.byline&&r.push(`Author/Source: ${a.byline}`),a.isYouTube&&r.push("Content Type: YouTube Video Transcript"),a.selection&&r.push(`Currently Selected Text: "${a.selection}"`);const n=(a.textContent||"").trim();return`${i}

====================
CURRENT WEBPAGE CONTEXT (AVAILABLE FOR REFERENCE):
${r.join(`
`)}

PAGE TEXT CONTENT:
"""
${n||"No text content available on this page."}
"""
====================`}return Me(a||{title:"",url:"",textContent:""},t)}function Me(a,t="en"){if(a.url&&he(a.url))return`You are Madadgar.
SECURITY POLICY: ${me}
Strictly refuse interaction with this page context.`;const e=ue[t]||ue.en,i=[];a.title&&i.push(`Page Title: "${a.title}"`),a.url&&i.push(`Page URL: ${a.url}`),a.byline&&i.push(`Author/Source: ${a.byline}`),a.isYouTube&&i.push("Content Type: YouTube Video Transcript"),a.selection&&i.push(`Currently Selected Text: "${a.selection}"`);const r=(a.textContent||"").trim();return`${e}

====================
CURRENT WEBPAGE CONTEXT:
${i.join(`
`)}

PAGE TEXT CONTENT:
"""
${r||"No text content available on this page."}
"""
====================`}function Oe(a,t=[],e){const i=[];for(const n of t)n.role==="user"?i.push({role:"user",parts:[{text:n.content}]}):n.role==="assistant"&&i.push({role:"model",parts:[{text:n.content}]});let r=a.trim();return e!=null&&e.selection&&!r.includes(e.selection)&&/this|selected|highlighted|quote/i.test(r)&&(r=`[Context regarding selected text: "${e.selection}"]

${r}`),i.push({role:"user",parts:[{text:r}]}),i}function W(a,t=80){if(!a)return"";const e=a.replace(/\s+/g," ").trim();return e.length<=t?e:e.slice(0,t-3)+"..."}function z(a){return a?Math.ceil(a.length/4):0}function $e(a,t={}){const{includeValues:e=!0,maxStringLength:i=80,markConsequential:r=!0,includeCoordinates:n=!1}=t,o=`#${a.id}`,s=a.tag.toLowerCase(),l=a.type?`:${a.type.toLowerCase()}`:"",c=a.role&&a.role!==s?` role="${a.role}"`:"";let m=`[${s}${l}]`;(s==="div"||s==="span"||s==="a")&&a.role&&(m=`[${a.role}]`);const g=W(a.label||a.text||a.placeholder||a.name||"unlabelled",i),u=[`${o} ${m} "${g}"${c}`];if(e){if(a.isPassword)u.push('(value: "••••••••")');else if(a.type==="checkbox"||a.type==="radio"){const d=a.currentValue==="checked"||a.currentValue==="true"||a.currentValue==="on";u.push(d?"(checked: true)":"(checked: false)")}else if(a.currentValue!==void 0&&a.currentValue!==null){const d=W(a.currentValue,i);u.push(`(value: "${d}")`)}else if(a.placeholder&&a.placeholder!==g){const d=W(a.placeholder,i);u.push(`(placeholder: "${d}")`)}}if(a.tag==="a"&&a.href)try{const d=new URL(a.href,"https://example.com"),f=d.pathname+d.search;f&&f!=="/"&&u.push(`(href: "${W(f,40)}")`)}catch{}if(a.disabled&&u.push("[disabled]"),r&&a.isConsequential&&u.push("[CONSEQUENTIAL]"),n&&a.rect){const d=Math.round(a.rect.left),f=Math.round(a.rect.top),p=Math.round(a.rect.width),w=Math.round(a.rect.height);u.push(`{x:${d},y:${f},w:${p},h:${w}}`)}return u.join(" ")}function U(a,t={}){if(!a||a.length===0)return"(No interactive elements detected)";const{maxElements:e=150,excludeDisabled:i=!0,includeHeader:r=!0}=t;let n=a;i&&(n=n.filter(l=>!l.disabled));const o=n.slice(0,e),s=o.map(l=>$e(l,t));return r?`=== Interactive Page Elements (Total: ${o.length}) ===
${s.join(`
`)}`:s.join(`
`)}function Ke(a,t=2e3){let e=U(a,{includeValues:!0,maxElements:120}),i=z(e);if(i<=t)return{serialized:e,estimatedTokens:i,elementCount:Math.min(a.length,120)};if(e=U(a,{includeValues:!0,maxStringLength:45,maxElements:80}),i=z(e),i<=t)return{serialized:e,estimatedTokens:i,elementCount:Math.min(a.length,80)};if(e=U(a,{includeValues:!1,maxStringLength:35,maxElements:50}),i=z(e),i<=t)return{serialized:e,estimatedTokens:i,elementCount:Math.min(a.length,50)};let r=1,n=Math.min(a.length,50),o=e,s=n,l=i;for(;r<=n;){const c=Math.floor((r+n)/2),m=U(a,{includeValues:!1,maxStringLength:30,maxElements:c}),g=z(m);g<=t?(o=m,s=c,l=g,r=c+1):n=c-1}return{serialized:o,estimatedTokens:l,elementCount:s}}function qe(a,t,e="en"){const r=e==="hinglish"?`Aap Madadgar ke Element Locator Engine hain. User ke sawal aur webpage ke numbered Action Map ko analyze karein. User ki query ke hisaab se sahi interactive element ka numeric target_id pehchanein.
Aapko strictly valid JSON format mein output dena hai:
{
  "target_id": <numeric_id_or_null>,
  "reason": "<clear_one_sentence_explanation_in_Hinglish>",
  "confidence": "high" | "medium" | "low"
}
Agar page par query se related koi element nahi milta, toh target_id ko null rakhein.`:`You are Madadgar's Element Locator Engine. Given a user search query and a numbered Action Map of interactive elements on the current webpage, identify the single most relevant element numeric target_id that fulfills the user's intent (e.g. "Where do I upload my resume?", "Where is the login button?").

Respond STRICTLY with a valid JSON object adhering to this schema:
{
  "target_id": <numeric_id_or_null>,
  "reason": "<clear_one_sentence_explanation_in_English>",
  "confidence": "high" | "medium" | "low"
}
Rules:
1. "target_id" must be an integer matching one of the #<id> badges from the Action Map, or null if no element matches.
2. "reason" must be a concise, direct explanation of why this element was selected.
3. "confidence" must be "high", "medium", or "low".
4. Do not include markdown code block backticks if possible, return raw JSON only.`,n=`User Query: "${a.trim()}"

Numbered Webpage Action Map:
${t}

Identify the target element matching the user's query:`;return{systemInstruction:r,userPrompt:n}}function Ge(a){if(!a||!a.trim())return{targetId:null,reason:"Empty response received from AI model.",confidence:"low"};let t=a.trim();const e=t.match(/```(?:json)?\s*([\s\S]*?)\s*```/);if(e)t=e[1].trim();else{const i=t.indexOf("{"),r=t.lastIndexOf("}");i!==-1&&r!==-1&&r>i&&(t=t.substring(i,r+1))}try{const i=JSON.parse(t),r=typeof i.target_id=="number"?i.target_id:typeof i.targetId=="number"?i.targetId:null,n=typeof i.reason=="string"&&i.reason.trim()?i.reason.trim():r!==null?`Located element #${r} matching your request.`:"Could not find a matching element on this page.",o=i.confidence==="high"||i.confidence==="medium"||i.confidence==="low"?i.confidence:"medium";return{targetId:r,reason:n,confidence:o}}catch(i){console.warn("[parseElementLocatorResponse] JSON parse failed, falling back to regex:",i);const r=a.match(/["']?target_?id["']?\s*:\s*(\d+|null)/i),n=a.match(/["']?reason["']?\s*:\s*["']([^"']+)["']/i);let o=null;r&&r[1]!=="null"&&(o=parseInt(r[1],10));const s=n?n[1]:o!==null?`Located element #${o}`:"Could not find a matching element on this page.";return{targetId:o,reason:s,confidence:o!==null?"medium":"low"}}}const Ue=new Set(["click","type","select","scroll","done","fail"]);function De(a,t,e=[],i,r="en"){var m,g;const o=r==="hinglish"?`Aap Madadgar ke Human-in-the-Loop Browser Agent hain.
Aapka kaam user ke goal ko step-by-step achieve karna hai. Webpage ke numbered Action Map ko dekhein aur agla single safe action propose karein.

Aapko STRICTLY valid JSON schema mein respond karna hai:
{
  "action": "click" | "type" | "select" | "scroll" | "done" | "fail",
  "target_id": <numeric_id_or_null>,
  "value": "<text_to_type_or_select_or_scroll_direction>",
  "reason": "<clear_one_sentence_explanation_in_Hinglish>",
  "is_consequential": true | false
}

Rules:
1. Ek waqt mein sirf EK step propose karein.
2. "target_id" numbered action map ke #<id> se match hona chahiye.
3. Agar form submit ho raha ho, payment ho rahi ho, ya delete action ho, toh "is_consequential": true set karein.
4. Agar goal achieve ho chuka hai, toh "action": "done" propose karein. Step 1 par ya jab tak goal ke interactions perform nahi hue hain, "done" propose na karein; pehla click ya type step propose karein.
5. Loop Prevention: Agar pichle step mein wohi button click kiya gaya tha aur page nahi badla, toh dobara wahi action propose na karein. Agar form submit nahi ho raha ya login fail ho raha hai, "fail" propose karein explanation ke saath.
6. Form-Filling Engine: Jab user profile se form fill karna ho, page ke input fields ko profile ke fields (Name, Email, Phone, College, Degree, Major, Year, Skills, LinkedIn, GitHub) se map karein aur ek-ek karke fill karein taaki user har step approve kar sake.
7. Markdown code fences ke bina sirf raw JSON return karein.`:`You are Madadgar's Human-in-the-Loop Autonomous Browser Agent.
Your goal is to accomplish the user's task step-by-step by analyzing the numbered Action Map of the current webpage and proposing the single best next action.

You MUST respond strictly with a valid JSON object adhering to this schema:
{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "title": "AgentActionProposal",
  "action": "click" | "type" | "select" | "scroll" | "done" | "fail",
  "target_id": <integer_or_null>,
  "value": "<string_or_undefined>",
  "reason": "<clear_one_sentence_plain_English_explanation>",
  "is_consequential": <boolean>
}

Core Rules:
1. Propose exactly ONE atomic action per step.
2. For "click": "target_id" must be an integer matching an element from the Action Map.
3. For "type": "target_id" must be the input/textarea ID, and "value" must be the text to type.
4. For "select": "target_id" must be the dropdown ID, and "value" must be the option text or value.
5. For "scroll": set "value" to "down", "up", "top", or "bottom".
6. If the user's overall goal is completed, output "action": "done" with a congratulatory reason. IMPORTANT: On Step 1 (or whenever the requested interactions have not yet been executed), DO NOT propose "done"; you MUST actively propose the click, type, select, or scroll step to perform the errand.
7. Set "is_consequential": true whenever an action submits a form, places an order, executes a delete, or makes a payment.
8. NEVER guess passwords, security codes, or credit card numbers. If encountered, set action to "fail" or ask the user.
9. Loop Prevention: DO NOT propose the exact same action and target_id repeatedly if it was already executed in recent steps and produced no state change or navigation. If a button was already clicked and the page is unchanged, do not click it again; analyze if an input field is missing, or conclude "fail" with an explanation.
10. Accurate Task Completion: DO NOT conclude "done" if the goal was to log in, submit, or search, but the page is still stuck on the initial unsubmitted form, login screen, or empty result page. Conclude "fail" with a clear reason instead of falsely claiming completion.
11. Profile Form-Filling Engine (Task 4.2): When the goal is to fill out a form or apply (e.g. "fill form", "apply from profile"):
    - Carefully inspect each unfilled input, textarea, and select element in the Action Map.
    - Correlate each field with the User Profile Memory (Name -> fullName, Email -> email, Phone -> phone, College/University -> institution, Degree -> degree, Major -> major, Graduation Year -> graduationYear, Skills -> skills, LinkedIn -> linkedInUrl, GitHub -> githubUrl, Portfolio -> portfolioUrl).
    - Propose ONE field fill per step so each proposal is displayed individually in the HITL approval card for user sign-off.
    - For text inputs, use "action": "type", "target_id": <id>, "value": "<mapped_profile_value>".
    - In "reason", explicitly state what profile data is being populated into which field (e.g., "Typing college name from user profile into institution field", "Typing email address from profile into field #2").
    - Once all available form fields are filled, propose clicking Next or Submit (marking "is_consequential": true for final submissions).
12. Return ONLY the JSON object. Do not enclose in markdown backticks or add introductory prose.`;let s="(No prior steps executed yet. This is Step 1.)";e.length>0&&(s=e.map(d=>{var h,b;const f=(h=d.result)!=null&&h.success?"Success":`Failed: ${((b=d.result)==null?void 0:b.error)||"unknown"}`,p=d.action.value?` (value: "${d.action.value}")`:"",w=d.action.target_id?` on #${d.action.target_id}`:"";return`- Step ${d.step}: [${d.action.action}]${w}${p} -> ${f} | Reason: ${d.action.reason}`}).join(`
`));let l="";if(i){const u=i.personal||{},d=i.academic||{},f=i.professional||{},p=[];u.fullName&&p.push(`- Full Name: ${u.fullName}`),u.email&&p.push(`- Email: ${u.email}`),u.phone&&p.push(`- Phone: ${u.phone}`),u.location&&p.push(`- Location: ${u.location}`),d.institution&&p.push(`- University/School: ${d.institution}`),d.degree&&p.push(`- Degree: ${d.degree}`),d.major&&p.push(`- Major: ${d.major}`),d.graduationYear&&p.push(`- Graduation Year: ${d.graduationYear}`),(m=f.skills)!=null&&m.length&&p.push(`- Skills: ${f.skills.join(", ")}`),f.linkedInUrl&&p.push(`- LinkedIn: ${f.linkedInUrl}`),f.githubUrl&&p.push(`- GitHub: ${f.githubUrl}`),f.portfolioUrl&&p.push(`- Portfolio: ${f.portfolioUrl}`),(g=i.preferences)!=null&&g.tone&&p.push(`- Preferred Writing Tone: ${i.preferences.tone}`),p.length>0&&(l=`

User Profile Memory (Available to fill relevant forms):
${p.join(`
`)}`)}const c=`User Goal: "${a.trim()}"

Previous Steps History:
${s}${l}

Active Page Numbered Action Map:
${t}

Propose the single best next action in strict JSON:`;return{systemInstruction:o,userPrompt:c}}function Ye(a,t){return{systemInstruction:"You are a JSON syntax and schema repair assistant. Output ONLY a valid JSON object matching the required AgentActionProposal schema.",userPrompt:`Your previous output could not be parsed or violated the required schema:
Error: ${t}

Your previous output was:
${a}

Please output ONLY the corrected JSON object now with no markdown fences:`}}function de(a){if(!a||!a.trim())throw new Error("Empty response received from agent planner.");let t=a.trim();t.startsWith("```")&&(t=t.replace(/^```(?:json)?\s*/i,"").replace(/\s*```$/,"").trim());let e;try{e=JSON.parse(t)}catch{const c=t.match(/\{[\s\S]*\}/);if(c)e=JSON.parse(c[0]);else throw new Error(`Model response is not valid JSON: "${t.slice(0,80)}..."`)}if(typeof e!="object"||e===null)throw new Error("Parsed response is not a valid JSON object.");const i=String(e.action||"").toLowerCase().trim();if(!Ue.has(i))throw new Error(`Invalid action "${i}". Must be one of: click, type, select, scroll, done, fail.`);const r=i,n=typeof e.reason=="string"&&e.reason.trim()?e.reason.trim():`Executing ${r}`;let o;if(e.target_id!==void 0&&e.target_id!==null){const c=parseInt(String(e.target_id),10);isNaN(c)||(o=c)}else if(e.targetId!==void 0&&e.targetId!==null){const c=parseInt(String(e.targetId),10);isNaN(c)||(o=c)}if((r==="click"||r==="type"||r==="select")&&o===void 0)throw new Error(`Action "${r}" requires a valid numeric target_id.`);let s;e.value!==void 0&&e.value!==null&&(s=String(e.value));const l=!!(e.is_consequential||e.isConsequential);return{action:r,target_id:o,value:s,reason:n,is_consequential:l}}class ee extends Error{constructor(e,i=60,r=["gemini"]){super(e);E(this,"cooldownSeconds");E(this,"providers");this.name="RateLimitCooldownError",this.cooldownSeconds=i,this.providers=r}}class te{static async sleep(t,e){if(e!=null&&e.aborted)throw new Error("Operation aborted");return new Promise((i,r)=>{const n=setTimeout(()=>{e&&e.removeEventListener("abort",o),i()},t),o=()=>{clearTimeout(n),e&&e.removeEventListener("abort",o),r(new Error("Operation aborted"))};e&&e.addEventListener("abort",o)})}static subscribeRateLimit(t){return this.rateLimitListeners.add(t),t(this.getRateLimitStatus()),()=>{this.rateLimitListeners.delete(t)}}static subscribeFailover(t){return this.failoverListeners.add(t),()=>{this.failoverListeners.delete(t)}}static getRateLimitStatus(){return this.rateLimitStatus?Date.now()>=this.rateLimitStatus.expiresAt?(this.rateLimitStatus=null,null):{...this.rateLimitStatus}:null}static setRateLimitCooldown(t=60,e=["gemini"],i){const r={isActive:!0,cooldownSeconds:t,expiresAt:Date.now()+t*1e3,providers:e,message:i};return this.rateLimitStatus=r,this.rateLimitListeners.forEach(n=>n(r)),r}static clearRateLimitStatus(){this.rateLimitStatus=null,this.rateLimitListeners.forEach(t=>t(null))}static notifyFailover(t){this.failoverListeners.forEach(e=>e(t))}static async executeWithRetry(t,e){var l;const i=(e==null?void 0:e.maxRetries)??2,r=(e==null?void 0:e.initialDelayMs)??1500,n=(e==null?void 0:e.backoffFactor)??2,o=(e==null?void 0:e.retryableStatuses)??[429,503];let s=0;for(;;)try{return await t()}catch(c){const m=c instanceof _&&o.includes(c.status),g=c instanceof D&&o.includes(c.status);if(!(m||g)||s>=i||(l=e==null?void 0:e.signal)!=null&&l.aborted)throw c;s++;const d=r*Math.pow(n,s-1),f=c.status;console.warn(`[AIGateway] Retryable HTTP ${f} encountered. Retrying attempt ${s}/${i} after ${d}ms...`),await this.sleep(d,e==null?void 0:e.signal)}}static async executeWithResilience(t){const e=this.getRateLimitStatus();if(e&&e.isActive){const i=Math.max(0,Math.ceil((e.expiresAt-Date.now())/1e3));if(i>0)throw new ee(`Free-tier rate limit cooldown active. Please wait ${i}s.`,i,e.providers);this.clearRateLimitStatus()}try{return await this.executeWithRetry(t.geminiAction,{maxRetries:2,initialDelayMs:1500,backoffFactor:2,signal:t.signal})}catch(i){if(i instanceof _&&(i.status===429||i.status===503)&&t.groqAction){const n=await B();if(n.groqApiKey&&n.groqApiKey.trim()){const o={from:"gemini",to:"groq",model:Q,reason:i.status===429?"RATE_LIMIT_429":"SERVICE_UNAVAILABLE_503",timestamp:Date.now()};console.warn(`[AIGateway] Gemini quota reached (${i.status}), failing over to Groq (${Q})...`),this.notifyFailover(o);try{return await this.executeWithRetry(t.groqAction,{maxRetries:2,initialDelayMs:1500,backoffFactor:2,signal:t.signal})}catch(s){throw console.error("[AIGateway] Groq fallback also failed:",s),this.setRateLimitCooldown(60,["gemini","groq"],"Both Gemini and Groq rate limits were exceeded."),new ee("Both Gemini and Groq providers are currently rate-limited. Please wait for cooldown.",60,["gemini","groq"])}}}throw i instanceof _&&i.status===429?(this.setRateLimitCooldown(60,["gemini"],"Gemini free-tier quota exhausted. Consider adding a Groq fallback key."),new ee("Gemini free-tier quota exhausted. Please wait for cooldown or configure Groq fallback key in Settings.",60,["gemini"])):i}}static async resolveApiKey(t){if(t!==void 0){if(!t.trim())throw new Error("Gemini API key is not configured. Please open Settings and enter a valid API key.");return t.trim()}const e=await B();if(!e.geminiApiKey||!e.geminiApiKey.trim())throw new Error("Gemini API key is not configured. Please open Settings and enter a valid API key.");return e.geminiApiKey.trim()}static async resolveGroqApiKey(){const t=await B();return t.groqApiKey&&t.groqApiKey.trim()?t.groqApiKey.trim():void 0}static async resolveLanguage(t){return t||(await B()).defaultLanguage||"en"}static async summarizeArticle(t,e){const i=await this.resolveApiKey(e==null?void 0:e.apiKey),r=await this.resolveGroqApiKey(),n=await this.resolveLanguage(e==null?void 0:e.language),{systemInstruction:o,userPrompt:s}=le(t,{...e,language:n}),l=await this.executeWithResilience({taskName:"summarizeArticle",signal:e==null?void 0:e.signal,geminiAction:()=>O({apiKey:i,prompt:s,systemInstruction:o,config:e==null?void 0:e.config,signal:e==null?void 0:e.signal}),groqAction:r?()=>K({apiKey:r,messages:x(s,o),signal:e==null?void 0:e.signal}):void 0});return F(l)}static async summarizeArticleStream(t,e){const i=await this.resolveApiKey(e==null?void 0:e.apiKey),r=await this.resolveGroqApiKey(),n=await this.resolveLanguage(e==null?void 0:e.language),{systemInstruction:o,userPrompt:s}=le(t,{...e,language:n}),l=await this.executeWithResilience({taskName:"summarizeArticleStream",signal:e==null?void 0:e.signal,geminiAction:()=>G({apiKey:i,prompt:s,systemInstruction:o,config:e==null?void 0:e.config,signal:e==null?void 0:e.signal,onChunk:e==null?void 0:e.onChunk}),groqAction:r?()=>H({apiKey:r,messages:x(s,o),signal:e==null?void 0:e.signal,onChunk:e==null?void 0:e.onChunk}):void 0});return F(l)}static async summarizeYouTube(t,e){const i=await this.resolveApiKey(e==null?void 0:e.apiKey),r=await this.resolveGroqApiKey(),n=await this.resolveLanguage(e==null?void 0:e.language),{systemInstruction:o,userPrompt:s}=ce(t,{...e,language:n}),l=await this.executeWithResilience({taskName:"summarizeYouTube",signal:e==null?void 0:e.signal,geminiAction:()=>O({apiKey:i,prompt:s,systemInstruction:o,config:e==null?void 0:e.config,signal:e==null?void 0:e.signal}),groqAction:r?()=>K({apiKey:r,messages:x(s,o),signal:e==null?void 0:e.signal}):void 0});return F(l)}static async summarizeYouTubeStream(t,e){const i=await this.resolveApiKey(e==null?void 0:e.apiKey),r=await this.resolveGroqApiKey(),n=await this.resolveLanguage(e==null?void 0:e.language),{systemInstruction:o,userPrompt:s}=ce(t,{...e,language:n}),l=await this.executeWithResilience({taskName:"summarizeYouTubeStream",signal:e==null?void 0:e.signal,geminiAction:()=>G({apiKey:i,prompt:s,systemInstruction:o,config:e==null?void 0:e.config,signal:e==null?void 0:e.signal,onChunk:e==null?void 0:e.onChunk}),groqAction:r?()=>H({apiKey:r,messages:x(s,o),signal:e==null?void 0:e.signal,onChunk:e==null?void 0:e.onChunk}):void 0});return F(l)}static async groundedChatStream(t){const e=await this.resolveApiKey(t.apiKey),i=await this.resolveGroqApiKey(),r=await this.resolveLanguage(t.language),n=t.mode||"grounded",o=Re(t.context,r,n),s=Oe(t.query,t.history,t.context||void 0);return this.executeWithResilience({taskName:"groundedChatStream",signal:t.signal,geminiAction:()=>G({apiKey:e,prompt:s,systemInstruction:o,config:t.config,signal:t.signal,onChunk:t.onChunk}),groqAction:i?()=>H({apiKey:i,messages:x(s,o),signal:t.signal,onChunk:t.onChunk}):void 0})}static async inspectVisualStream(t){const e=await this.resolveApiKey(t.apiKey),r=await this.resolveLanguage(t.language)==="hinglish",n=t.pageContext?`Webpage Title: "${t.pageContext.title}"
Webpage URL: ${t.pageContext.url}

`:"",o=r?"Aap Madadgar ke Visual Intelligence Engine hain. User ki active browser screen ke screenshot ko deeply analyze karein. Charts, diagrams, user interface, tables, text aur visuals par puche gaye sawalon ka Hinglish (Roman Urdu/Hindi) mein accurate aur grounded jawab dein. Agar visuals mein koi information clear nahi hai toh saaf batayein.":"You are Madadgar's Visual Intelligence Engine. Carefully analyze the provided browser viewport screenshot. Accurately answer questions regarding charts, graphs, tables, UI diagrams, error codes, visual layout, and visible text. Be concise, grounded strictly in the visible pixels, and highlight key visual observations. If information is not visible in the screenshot, clearly state so.",s=[{role:"user",parts:[{text:`${n}${t.prompt}`},{inlineData:{mimeType:t.mimeType||"image/jpeg",data:t.imageBase64}}]}];return this.executeWithResilience({taskName:"inspectVisualStream",signal:t.signal,geminiAction:()=>G({apiKey:e,prompt:s,model:oe,systemInstruction:o,config:t.config,signal:t.signal,onChunk:t.onChunk})})}static async inspectVisual(t){const e=await this.resolveApiKey(t.apiKey),r=await this.resolveLanguage(t.language)==="hinglish",n=t.pageContext?`Webpage Title: "${t.pageContext.title}"
Webpage URL: ${t.pageContext.url}

`:"",o=r?"Aap Madadgar ke Visual Intelligence Engine hain. User ki active browser screen ke screenshot ko deeply analyze karein. Charts, diagrams, user interface, tables, text aur visuals par puche gaye sawalon ka Hinglish (Roman Urdu/Hindi) mein accurate aur grounded jawab dein.":"You are Madadgar's Visual Intelligence Engine. Carefully analyze the provided browser viewport screenshot. Accurately answer questions regarding charts, graphs, tables, UI diagrams, error codes, visual layout, and visible text. Be concise, grounded strictly in the visible pixels, and highlight key visual observations.",s=[{role:"user",parts:[{text:`${n}${t.prompt}`},{inlineData:{mimeType:t.mimeType||"image/jpeg",data:t.imageBase64}}]}];return this.executeWithResilience({taskName:"inspectVisual",signal:t.signal,geminiAction:()=>O({apiKey:e,prompt:s,model:oe,systemInstruction:o,config:t.config,signal:t.signal})})}static async complete(t){const e=await this.resolveApiKey(t.apiKey),i=await this.resolveGroqApiKey();return this.executeWithResilience({taskName:"complete",signal:t.signal,geminiAction:()=>O({apiKey:e,prompt:t.prompt,systemInstruction:t.systemInstruction,config:t.config,signal:t.signal}),groqAction:i?()=>K({apiKey:i,messages:x(t.prompt,t.systemInstruction),signal:t.signal}):void 0})}static async completeStream(t){const e=await this.resolveApiKey(t.apiKey),i=await this.resolveGroqApiKey();return this.executeWithResilience({taskName:"completeStream",signal:t.signal,geminiAction:()=>G({apiKey:e,prompt:t.prompt,systemInstruction:t.systemInstruction,config:t.config,signal:t.signal,onChunk:t.onChunk}),groqAction:i?()=>H({apiKey:i,messages:x(t.prompt,t.systemInstruction),signal:t.signal,onChunk:t.onChunk}):void 0})}static async locateElement(t,e,i){if(!e||e.length===0)return{targetId:null,reason:"No interactive elements detected on this page.",confidence:"low"};const r=await this.resolveApiKey(i==null?void 0:i.apiKey),n=await this.resolveGroqApiKey(),o=await this.resolveLanguage(i==null?void 0:i.language),s=U(e,{includeValues:!0,maxElements:120}),{systemInstruction:l,userPrompt:c}=qe(t,s,o),m=await this.executeWithResilience({taskName:"locateElement",signal:i==null?void 0:i.signal,geminiAction:()=>O({apiKey:r,prompt:c,systemInstruction:l,config:i==null?void 0:i.config,signal:i==null?void 0:i.signal}),groqAction:n?()=>K({apiKey:n,messages:x(c,l),signal:i==null?void 0:i.signal}):void 0}),g=typeof m=="string"?m:(m==null?void 0:m.text)||JSON.stringify(m);return Ge(g)}static async proposeNextAction(t,e,i=[],r,n){if(!e||e.length===0)return{action:"fail",reason:"No interactive elements detected on the active webpage to interact with."};const o=await this.resolveApiKey(n==null?void 0:n.apiKey),s=await this.resolveGroqApiKey(),l=await this.resolveLanguage(n==null?void 0:n.language),{serialized:c}=Ke(e,2200),{systemInstruction:m,userPrompt:g}=De(t,c,i,r,l),u=await this.executeWithResilience({taskName:"proposeNextAction",signal:n==null?void 0:n.signal,geminiAction:()=>O({apiKey:o,prompt:g,systemInstruction:m,config:{temperature:.2,...n==null?void 0:n.config},signal:n==null?void 0:n.signal}),groqAction:s?()=>K({apiKey:s,messages:x(g,m),signal:n==null?void 0:n.signal}):void 0}),d=typeof u=="string"?u:(u==null?void 0:u.text)||JSON.stringify(u);try{return de(d)}catch(f){console.warn("[AIGateway] Initial proposal parsing failed, retrying with error-correction prompt:",f);const p=f instanceof Error?f.message:String(f),w=Ye(d,p),h=await this.executeWithResilience({taskName:"proposeNextAction_repair",signal:n==null?void 0:n.signal,geminiAction:()=>O({apiKey:o,prompt:w.userPrompt,systemInstruction:w.systemInstruction,config:{temperature:.1},signal:n==null?void 0:n.signal}),groqAction:s?()=>K({apiKey:s,messages:x(w.userPrompt,w.systemInstruction),signal:n==null?void 0:n.signal}):void 0}),b=typeof h=="string"?h:(h==null?void 0:h.text)||JSON.stringify(h);return de(b)}}}E(te,"rateLimitStatus",null),E(te,"rateLimitListeners",new Set),E(te,"failoverListeners",new Set);export{te as A,T as D,ge as G,se as M,ve as P,ee as R,Qe as a,ze as b,Je as c,ke as d,Xe as e,pe as f,Ne as g,B as h,xe as i,Le as j,Ve as k,Ze as l,Fe as m,tt as n,at as o,et as p,Ce as q,X as r,We as s,st as t,ot as u,nt as v,rt as w,it as x};
