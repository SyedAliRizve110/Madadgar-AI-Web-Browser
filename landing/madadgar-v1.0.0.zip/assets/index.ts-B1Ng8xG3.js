var D=Object.defineProperty;var P=(l,t,e)=>t in l?D(l,t,{enumerable:!0,configurable:!0,writable:!0,value:e}):l[t]=e;var f=(l,t,e)=>P(l,typeof t!="symbol"?t+"":t,e);import{e as _,a as q}from"./extractor-BIgEXCAK.js";import{v as L}from"./field_sanitizer-9mDfRKgA.js";import{i as F,S as T}from"./domain_rules-CwjSZosE.js";var y={};const Y=["button","a[href]",'input:not([type="hidden"])',"textarea","select",'[role="button"]','[role="link"]','[role="checkbox"]','[role="radio"]','[role="tab"]','[role="combobox"]','[role="menuitem"]','[role="switch"]','[tabindex="0"]','[contenteditable="true"]',"summary"].join(", ");class g{static clear(){for(const t of this.elementRegistry.values())try{t.removeAttribute("data-madadgar-id")}catch{}this.elementRegistry.clear(),this.lastScannedElements=[]}static getElementById(t){const e=this.elementRegistry.get(t);if(!e||!e.isConnected){if(typeof document<"u"){const n=document.querySelector(`[data-madadgar-id="${t}"]`);if(n&&n.isConnected)return this.elementRegistry.set(t,n),n}return null}return e}static getRegistry(){return new Map(this.elementRegistry)}static getLastScannedElements(){return[...this.lastScannedElements]}static isElementVisible(t,e=!1){var s,i;if(!t||!t.isConnected||t.id==="madadgar-overlay-host"||t.id==="madadgar-overlay-root"||t.hasAttribute("data-madadgar-overlay")||t.closest("#madadgar-overlay-host"))return!1;const n=typeof window<"u"&&(((i=(s=window.navigator)==null?void 0:s.userAgent)==null?void 0:i.includes("jsdom"))||(y==null?void 0:y.VITEST)==="true"||!1);if(typeof window<"u"&&window.getComputedStyle){const r=window.getComputedStyle(t);if(r.display==="none"||r.visibility==="hidden"||r.visibility==="collapse"||parseFloat(r.opacity||"1")===0||!n&&t.offsetParent===null&&r.position!=="fixed"&&r.position!=="sticky"&&t.tagName!=="BODY"&&t.tagName!=="HTML"&&!e)return!1}const o=t.getBoundingClientRect();return!(!e&&!n&&(o.width<=0||o.height<=0)||!e&&(o.bottom<-5e3||o.top>15e4))}static extractLabel(t){var c,d,m,p;const e=t.getAttribute("aria-label");if(e&&e.trim())return e.trim();const n=t.getAttribute("aria-labelledby");if(n){const h=document.getElementById(n);if(h&&((c=h.textContent)!=null&&c.trim()))return h.textContent.trim()}if(t.id){const h=document.querySelector(`label[for="${CSS.escape(t.id)}"]`);if(h&&((d=h.textContent)!=null&&d.trim()))return h.textContent.trim()}const o=t.closest("label");if(o&&((m=o.textContent)!=null&&m.trim())){const h=o.cloneNode(!0);for(const v of h.querySelectorAll("input, select, textarea"))v.remove();const w=(p=h.textContent)==null?void 0:p.trim();if(w)return w}const s=t.getAttribute("placeholder");if(s&&s.trim())return s.trim();const i=t.getAttribute("title");if(i&&i.trim())return i.trim();if(t instanceof HTMLInputElement&&(t.type==="submit"||t.type==="button")&&t.value&&t.value.trim())return t.value.trim();const r=t.innerText||t.textContent;if(r&&r.trim())return r.replace(/\s+/g," ").trim().slice(0,100);const a=t.getAttribute("name");return a&&a.trim()?a.trim():""}static extractCurrentValue(t){var e;if(t instanceof HTMLInputElement)return t.type==="checkbox"||t.type==="radio"?t.checked?"checked":"unchecked":t.type==="password"?t.value?"••••••••":"":t.value||"";if(t instanceof HTMLTextAreaElement)return t.value||"";if(t instanceof HTMLSelectElement){const n=t.options[t.selectedIndex];return(n==null?void 0:n.text)||t.value||""}return t.isContentEditable&&((e=t.textContent)==null?void 0:e.trim())||""}static isPasswordElement(t){if(t instanceof HTMLInputElement&&t.type==="password")return!0;const e=(t.getAttribute("autocomplete")||"").toLowerCase();return!!(e.includes("current-password")||e.includes("new-password"))}static isConsequentialElement(t,e){const n=`${e} ${t.getAttribute("type")||""} ${t.getAttribute("name")||""}`.toLowerCase();return/(\b(submit|pay|buy|purchase|delete|remove|transfer|place order|confirm order|checkout|cancel subscription)\b)/i.test(n)}static scan(t=document,e={}){this.clear();const n=typeof process<"u"&&(y==null?void 0:y.VITEST)==="true",o=e.allowZeroRectInTest??n,s=e.maxElements??250,i=t.querySelectorAll(Y),r=[];let a=1;for(let c=0;c<i.length&&!(r.length>=s);c++){const d=i[c];if(!this.isElementVisible(d,o))continue;const m=a++;d.setAttribute("data-madadgar-id",String(m)),this.elementRegistry.set(m,d);const p=d.tagName.toLowerCase(),h=d.getAttribute("type")||(p==="input"?"text":void 0),w=d.getAttribute("name")||void 0,v=d.getAttribute("placeholder")||void 0,B=d.getAttribute("role")||void 0,k=d.getAttribute("href")||void 0,H=d.hasAttribute("disabled")||d.getAttribute("aria-disabled")==="true",S=this.extractLabel(d),N=this.extractCurrentValue(d),R=this.isPasswordElement(d),O=this.isConsequentialElement(d,S),b=d.getBoundingClientRect(),V={top:Math.round(b.top),left:Math.round(b.left),width:Math.round(b.width),height:Math.round(b.height),bottom:Math.round(b.bottom),right:Math.round(b.right)},$={id:m,tag:p,type:h,name:w,label:S||void 0,placeholder:v,currentValue:N||void 0,text:(d.innerText||d.textContent||"").replace(/\s+/g," ").trim().slice(0,100)||void 0,role:B,href:k,disabled:H||void 0,isPassword:R||void 0,isConsequential:!!O,rect:V};r.push($)}return this.lastScannedElements=r,r}static attachObserver(t,e=400){if(this.observer&&(this.observer.disconnect(),this.observer=null),typeof MutationObserver>"u")return()=>{};let n=null;this.observer=new MutationObserver(o=>{o.every(i=>{var a;const r=i.target;return(r==null?void 0:r.id)==="madadgar-overlay-host"||(r==null?void 0:r.id)==="madadgar-overlay-root"||((a=r==null?void 0:r.hasAttribute)==null?void 0:a.call(r,"data-madadgar-overlay"))})||(n&&clearTimeout(n),n=setTimeout(()=>{t()},e))});try{this.observer.observe(document.body||document.documentElement,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["class","style","hidden","disabled"]})}catch{}return()=>{n&&clearTimeout(n),this.observer&&(this.observer.disconnect(),this.observer=null)}}}f(g,"elementRegistry",new Map),f(g,"observer",null),f(g,"lastScannedElements",[]);var x={};const I="madadgar-overlay-host",M="madadgar-overlay-root",G=`
:host {
  all: initial !important;
}

#madadgar-overlay-root {
  position: fixed !important;
  top: 0 !important;
  left: 0 !important;
  width: 100vw !important;
  height: 100vh !important;
  pointer-events: none !important;
  z-index: 2147483647 !important;
  overflow: hidden !important;
  font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace !important;
}

/* Numbered Badges */
.madadgar-badge {
  position: fixed !important;
  display: inline-flex !important;
  align-items: center !important;
  justify-content: center !important;
  background: #4f46e5 !important; /* Indigo 600 */
  color: #ffffff !important;
  font-size: 11px !important;
  font-weight: 700 !important;
  line-height: 1 !important;
  padding: 2.5px 5.5px !important;
  border-radius: 4px !important;
  border: 1px solid rgba(255, 255, 255, 0.7) !important;
  box-shadow: 0 2px 5px rgba(0, 0, 0, 0.35), 0 0 0 1px rgba(79, 70, 229, 0.4) !important;
  pointer-events: none !important;
  transform: translate(-30%, -60%) !important;
  transition: transform 0.12s cubic-bezier(0.4, 0, 0.2, 1), opacity 0.12s ease !important;
  user-select: none !important;
  white-space: nowrap !important;
}

.madadgar-badge.active-target {
  background: #10b981 !important; /* Emerald 500 */
  border-color: #ffffff !important;
  transform: translate(-30%, -60%) scale(1.15) !important;
  box-shadow: 0 0 0 2px #ffffff, 0 0 10px rgba(16, 185, 129, 0.8) !important;
}

.madadgar-badge.active-dry-run {
  background: #f59e0b !important; /* Amber 500 */
  border-color: #ffffff !important;
  transform: translate(-30%, -60%) scale(1.15) !important;
  box-shadow: 0 0 0 2px #ffffff, 0 0 10px rgba(245, 158, 11, 0.8) !important;
}

.madadgar-badge.pulse {
  animation: madadgar-badge-pulse 1.2s infinite ease-in-out !important;
}

@keyframes madadgar-badge-pulse {
  0%, 100% {
    transform: translate(-30%, -60%) scale(1);
    box-shadow: 0 0 0 0 rgba(79, 70, 229, 0.6);
  }
  50% {
    transform: translate(-30%, -60%) scale(1.35);
    background: #f59e0b !important;
    box-shadow: 0 0 0 6px rgba(245, 158, 11, 0);
  }
}

/* Proposed Action Highlight Box */
.madadgar-highlight-proposed {
  position: fixed !important;
  border: 2px solid #10b981 !important; /* Emerald 500 */
  background: rgba(16, 185, 129, 0.15) !important;
  border-radius: 4px !important;
  pointer-events: none !important;
  box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.35), 0 0 14px rgba(16, 185, 129, 0.5) !important;
  transition: all 0.15s ease-out !important;
  animation: madadgar-proposed-glow 2s infinite ease-in-out !important;
}

@keyframes madadgar-proposed-glow {
  0%, 100% {
    box-shadow: 0 0 0 2px rgba(16, 185, 129, 0.35), 0 0 10px rgba(16, 185, 129, 0.4);
  }
  50% {
    box-shadow: 0 0 0 3px rgba(16, 185, 129, 0.55), 0 0 18px rgba(16, 185, 129, 0.7);
  }
}

/* Dry-Run Inspection Highlight Box */
.madadgar-highlight-dry-run {
  position: fixed !important;
  border: 2px dashed #f59e0b !important; /* Amber 500 */
  background: rgba(245, 158, 11, 0.15) !important;
  border-radius: 4px !important;
  pointer-events: none !important;
  box-shadow: 0 0 0 2px rgba(245, 158, 11, 0.3), 0 0 12px rgba(245, 158, 11, 0.4) !important;
  transition: all 0.15s ease-out !important;
}

/* "Find It For Me" Pulse Locator Highlight Box (Task 3.4) */
.madadgar-highlight-pulse {
  position: fixed !important;
  border: 2.5px solid #6366f1 !important; /* Indigo 500 */
  background: rgba(99, 102, 241, 0.2) !important;
  border-radius: 6px !important;
  pointer-events: none !important;
  animation: madadgar-locator-pulse 1.2s infinite ease-in-out !important;
}

@keyframes madadgar-locator-pulse {
  0%, 100% {
    box-shadow: 0 0 0 2px rgba(99, 102, 241, 0.4), 0 0 10px rgba(99, 102, 241, 0.5);
  }
  50% {
    box-shadow: 0 0 0 5px rgba(99, 102, 241, 0.7), 0 0 24px rgba(99, 102, 241, 0.8);
    background: rgba(99, 102, 241, 0.3) !important;
  }
}
`;class u{static getShadowRoot(){return this.shadowRoot}static getCurrentElements(){return[...this.currentElements]}static ensureContainer(){if(this.rootContainer&&this.rootContainer.isConnected)return this.rootContainer;if(typeof document>"u")throw new Error("BadgeOverlay requires browser DOM environment.");let t=document.getElementById(I);t||(t=document.createElement("div"),t.id=I,t.setAttribute("data-madadgar-overlay","true"),(document.body||document.documentElement).appendChild(t)),this.hostElement=t;let e=t.shadowRoot;if(!e){e=t.attachShadow({mode:"open"});const o=document.createElement("style");o.textContent=G,e.appendChild(o)}this.shadowRoot=e;let n=e.getElementById(M);return n||(n=document.createElement("div"),n.id=M,e.appendChild(n)),this.rootContainer=n,this.bindPositionListeners(),n}static bindPositionListeners(){if(this.scrollListenerBound||typeof window>"u")return;const t=()=>{this.rafId&&cancelAnimationFrame(this.rafId),this.rafId=requestAnimationFrame(()=>{this.updateBadgeCoordinates()})};window.addEventListener("scroll",t,{passive:!0,capture:!0}),window.addEventListener("resize",t,{passive:!0}),this.scrollListenerBound=!0}static renderBadges(t){var o,s;const e=this.ensureContainer();this.clearBadges(),this.currentElements=t;const n=typeof window<"u"&&(((s=(o=window.navigator)==null?void 0:o.userAgent)==null?void 0:s.includes("jsdom"))||(x==null?void 0:x.VITEST)==="true"||!1);for(const i of t){const r=g.getElementById(i.id);if(!r||!r.isConnected)continue;const a=r.getBoundingClientRect();if(!n&&a.width<=0&&a.height<=0)continue;const c=document.createElement("div");c.className="madadgar-badge",c.dataset.badgeId=String(i.id),c.textContent=`[${i.id}]`,c.style.top=`${Math.round(a.top)}px`,c.style.left=`${Math.round(a.left)}px`,e.appendChild(c),this.badgeElements.set(i.id,c)}}static updateBadgeCoordinates(){for(const[t,e]of this.badgeElements.entries()){const n=g.getElementById(t);if(!n||!n.isConnected){e.style.opacity="0";continue}const o=n.getBoundingClientRect();o.bottom<0||o.top>window.innerHeight||o.right<0||o.left>window.innerWidth||o.width===0&&o.height===0?e.style.opacity="0":(e.style.opacity="1",e.style.top=`${Math.round(o.top)}px`,e.style.left=`${Math.round(o.left)}px`)}if(this.activeHighlightEl){const t=this.activeHighlightEl.dataset.targetId;if(t){const e=parseInt(t,10),n=g.getElementById(e);if(n&&n.isConnected){const o=n.getBoundingClientRect();this.activeHighlightEl.style.top=`${Math.round(o.top)}px`,this.activeHighlightEl.style.left=`${Math.round(o.left)}px`,this.activeHighlightEl.style.width=`${Math.round(o.width)}px`,this.activeHighlightEl.style.height=`${Math.round(o.height)}px`}}}}static highlightTarget(t,e="proposed",n=!0){const o=this.ensureContainer();this.clearHighlights();const s=g.getElementById(t);if(!s||!s.isConnected)return!1;if(n&&typeof s.scrollIntoView=="function")try{s.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{}const i=s.getBoundingClientRect(),r=document.createElement("div");r.className=e==="dry-run"?"madadgar-highlight-dry-run":e==="pulse"?"madadgar-highlight-pulse":"madadgar-highlight-proposed",r.dataset.targetId=String(t),r.style.top=`${Math.round(i.top)}px`,r.style.left=`${Math.round(i.left)}px`,r.style.width=`${Math.round(i.width)}px`,r.style.height=`${Math.round(i.height)}px`,o.appendChild(r),this.activeHighlightEl=r;const a=this.badgeElements.get(t);return a&&(e==="dry-run"?a.classList.add("active-dry-run"):e==="pulse"?a.classList.add("pulse"):a.classList.add("active-target")),!0}static clearHighlights(){this.activeHighlightEl&&(this.activeHighlightEl.remove(),this.activeHighlightEl=null);for(const t of this.badgeElements.values())t.classList.remove("active-target","active-dry-run","pulse")}static clearBadges(){this.clearHighlights();for(const t of this.badgeElements.values())t.remove();this.badgeElements.clear(),this.currentElements=[]}static destroy(){this.clearBadges(),this.hostElement&&this.hostElement.parentNode&&this.hostElement.parentNode.removeChild(this.hostElement),this.hostElement=null,this.shadowRoot=null,this.rootContainer=null}}f(u,"hostElement",null),f(u,"shadowRoot",null),f(u,"rootContainer",null),f(u,"badgeElements",new Map),f(u,"activeHighlightEl",null),f(u,"currentElements",[]),f(u,"scrollListenerBound",!1),f(u,"rafId",null);class U{static async execute(t,e=!1){const{action:n,target_id:o,value:s,reason:i}=t;if(n==="done")return{success:!0,action:"done",value:s};if(n==="fail")return{success:!1,action:"fail",error:i||"Task marked as failed by agent planner."};if(n==="scroll"&&o==null)return{success:this.executeScroll(null,s||"down"),action:"scroll",value:s||"down"};if(typeof o!="number")return{success:!1,action:n,error:`Action "${n}" requires a numeric target_id, but none was provided.`};const r=g.getElementById(o);if(!r||!r.isConnected)return{success:!1,action:n,targetId:o,error:`Target element #${o} is no longer attached to the document.`};const a=L(r,n);if(!a.safe)return{success:!1,action:n,targetId:o,error:a.reason||"Blocked by credential safety guardrail."};if(e)return u.highlightTarget(o,"dry-run",!0),{success:!0,action:n,targetId:o,value:s,dryRun:!0};try{switch(n){case"click":return{success:this.executeClick(r),action:"click",targetId:o};case"type":{const c=s??"";return{success:this.executeType(r,c),action:"type",targetId:o,value:c}}case"select":{const c=s??"";return{success:this.executeSelect(r,c),action:"select",targetId:o,value:c}}case"scroll":return{success:this.executeScroll(r,s||"down"),action:"scroll",targetId:o,value:s||"down"};default:return{success:!1,action:n,targetId:o,error:`Unsupported action type: "${n}"`}}}catch(c){const d=c instanceof Error?c.message:String(c);return{success:!1,action:n,targetId:o,error:`Execution error on #${o}: ${d}`}}}static executeClick(t){if(this.isElementDisabled(t))throw new Error("Element is disabled or aria-disabled.");if(typeof t.scrollIntoView=="function")try{t.scrollIntoView({behavior:"smooth",block:"center",inline:"nearest"})}catch{}if(typeof t.focus=="function")try{t.focus({preventScroll:!0})}catch{t.focus()}const e={bubbles:!0,cancelable:!0,composed:!0};t.dispatchEvent(new MouseEvent("mousedown",e)),t.dispatchEvent(new MouseEvent("mouseup",e)),typeof t.click=="function"?t.click():t.dispatchEvent(new MouseEvent("click",e));try{const n=t.form||t.closest("form"),o=t.type==="submit"||t.getAttribute("type")==="submit"||t.tagName.toLowerCase()==="button"&&(!t.getAttribute("type")||t.getAttribute("type")==="submit");if(n&&o)if(typeof n.requestSubmit=="function")try{n.requestSubmit(t)}catch{try{HTMLFormElement.prototype.submit.call(n)}catch{n.dispatchEvent(new Event("submit",{bubbles:!0,cancelable:!0}))}}else try{HTMLFormElement.prototype.submit.call(n)}catch{n.dispatchEvent(new Event("submit",{bubbles:!0,cancelable:!0}))}}catch{}return!0}static executeType(t,e){var a,c;if(this.isElementDisabled(t))throw new Error("Element is disabled.");const n=t.tagName.toLowerCase(),o=n==="input",s=n==="textarea",i=t.isContentEditable;if(!o&&!s&&!i)throw new Error(`Cannot type into element with tag <${n}>.`);if(t.readOnly)throw new Error("Cannot type into read-only element.");if(typeof t.focus=="function"&&t.focus(),o){const d=t,m=typeof window<"u"?window.HTMLInputElement.prototype:null,p=m?(a=Object.getOwnPropertyDescriptor(m,"value"))==null?void 0:a.set:null;p?p.call(d,e):d.value=e}else if(s){const d=t,m=typeof window<"u"?window.HTMLTextAreaElement.prototype:null,p=m?(c=Object.getOwnPropertyDescriptor(m,"value"))==null?void 0:c.set:null;p?p.call(d,e):d.value=e}else i&&(t.textContent=e);const r={bubbles:!0,cancelable:!0,composed:!0};return t.dispatchEvent(new Event("input",r)),t.dispatchEvent(new Event("change",r)),!0}static executeSelect(t,e){if(t.tagName.toLowerCase()!=="select")throw new Error(`Target element is <${t.tagName.toLowerCase()}>, expected <select>.`);if(this.isElementDisabled(t))throw new Error("Select element is disabled.");const n=t,o=e.trim().toLowerCase();let s=-1;for(let r=0;r<n.options.length;r++){const a=n.options[r],c=a.value.trim().toLowerCase(),d=a.text.trim().toLowerCase();if(c===o||d===o||d.includes(o)){s=r;break}}if(s===-1)throw new Error(`Option matching "${e}" was not found in <select> dropdown.`);n.selectedIndex=s;const i={bubbles:!0,cancelable:!0};return n.dispatchEvent(new Event("input",i)),n.dispatchEvent(new Event("change",i)),!0}static executeScroll(t,e="down"){var s,i;if(t&&typeof t.scrollIntoView=="function")try{return t.scrollIntoView({behavior:"smooth",block:"center"}),!0}catch{return t.scrollIntoView(),!0}if(typeof window>"u")return!1;const n=e.toLowerCase(),o=450;switch(n){case"up":window.scrollBy({top:-o,behavior:"smooth"});break;case"down":window.scrollBy({top:o,behavior:"smooth"});break;case"top":window.scrollTo({top:0,behavior:"smooth"});break;case"bottom":window.scrollTo({top:((s=document.body)==null?void 0:s.scrollHeight)||((i=document.documentElement)==null?void 0:i.scrollHeight)||1e4,behavior:"smooth"});break;default:{const r=parseInt(e,10);isNaN(r)?window.scrollBy({top:o,behavior:"smooth"}):window.scrollBy({top:r,behavior:"smooth"})}}return!0}static isElementDisabled(t){return!!(t.disabled===!0||t.getAttribute("aria-disabled")==="true"||t.classList.contains("disabled"))}}class E{static checkActivePageSafety(){if(typeof window>"u")return{safe:!0};const t=window.location.href;return F(t)?(u.clearBadges(),this.renderSafetyBanner(T),{safe:!1,reason:T}):(this.removeSafetyBanner(),{safe:!0})}static validateElementExecution(t,e){const n=L(t,e);return n.safe?{safe:!0}:{safe:!1,error:n.reason||"Blocked by credential safety guardrail."}}static emergencyTeardown(){u.clearBadges(),this.removeSafetyBanner()}static renderSafetyBanner(t){if(!(typeof document>"u")&&!document.getElementById(this.bannerHostId))try{const e=document.createElement("div");e.id=this.bannerHostId,e.style.position="fixed",e.style.top="12px",e.style.left="50%",e.style.transform="translateX(-50%)",e.style.zIndex="2147483647",e.style.pointerEvents="none";const n=e.attachShadow({mode:"closed"}),o=document.createElement("div");o.setAttribute("data-madadgar-safety-banner","true"),o.style.cssText=`
        background-color: #fef2f2;
        border: 1px solid #f87171;
        color: #991b1b;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
        font-size: 12px;
        font-weight: 500;
        padding: 8px 14px;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
        display: flex;
        align-items: center;
        gap: 8px;
        pointer-events: auto;
      `,o.innerHTML=`
        <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#dc2626" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          <line x1="12" y1="8" x2="12" y2="12"/>
          <line x1="12" y1="16" x2="12.01" y2="16"/>
        </svg>
        <span>${t}</span>
      `,n.appendChild(o),document.body.appendChild(e)}catch(e){console.warn("[Madadgar] Could not mount safety banner:",e)}}static removeSafetyBanner(){if(typeof document>"u")return;document.querySelectorAll(`#${this.bannerHostId}`).forEach(e=>{e.parentNode?e.parentNode.removeChild(e):e.remove()})}}f(E,"bannerHostId","madadgar-safety-banner-host");function j(l,t,e){var o,s;const n=(l==null?void 0:l.type)||(l==null?void 0:l.action);if(n==="EXTRACT_READABILITY_CONTENT"){const i=E.checkActivePageSafety();return i.safe?(_(document).then(r=>{var c,d;const a=typeof window<"u"&&((d=(c=window.getSelection())==null?void 0:c.toString())==null?void 0:d.trim())||void 0;e({...r,selection:a})}).catch(r=>{const a=r instanceof Error?r.message:String(r);console.error("[Madadgar Content Script] Extraction failed:",a),e({title:(document==null?void 0:document.title)||"Untitled Page",textContent:"",byline:null,length:0,error:a})}),!0):(e({title:typeof document<"u"?document.title:"Restricted Page",textContent:"",byline:null,length:0,error:i.reason,isBlacklisted:!0}),!0)}if(n==="GET_PAGE_SELECTION"){const i=typeof window<"u"&&((s=(o=window.getSelection())==null?void 0:o.toString())==null?void 0:s.trim())||"";return e({selection:i}),!0}if(n==="SCAN_INTERACTIVE_DOM"){const i=E.checkActivePageSafety();if(!i.safe)return e({success:!1,count:0,elements:[],url:typeof window<"u"?window.location.href:"",title:typeof document<"u"?document.title:"",error:i.reason,isBlacklisted:!0}),!0;try{const r=g.scan(document);l.renderBadges!==!1&&u.renderBadges(r);const a={success:!0,count:r.length,elements:r,url:typeof window<"u"?window.location.href:"",title:typeof document<"u"?document.title:""};e(a)}catch(r){const a=r instanceof Error?r.message:String(r);console.error("[Madadgar Content Script] DOM scan failed:",a),e({success:!1,count:0,elements:[],url:typeof window<"u"?window.location.href:"",title:typeof document<"u"?document.title:"",error:a})}return!0}if(n==="RENDER_BADGES"){const i=g.getLastScannedElements();return u.renderBadges(i),e({success:!0,count:i.length}),!0}if(n==="CLEAR_BADGES"||n==="EMERGENCY_KILL_SWITCH")return E.emergencyTeardown(),g.clear(),e({success:!0}),!0;if(n==="HIGHLIGHT_ELEMENT"){const i=l.targetId;if(typeof i=="number"){const r=u.highlightTarget(i,l.mode||"proposed",l.scrollIntoView??!0);e({success:r})}else e({success:!1,error:"targetId must be a number"});return!0}if(n==="LOCATE_ELEMENT"){const i=l.targetId;if(typeof i=="number"){const r=u.highlightTarget(i,"pulse",!0);e({success:r,targetId:i})}else e({success:!1,error:"targetId must be a number"});return!0}if(n==="CLEAR_HIGHLIGHTS")return u.clearHighlights(),e({success:!0}),!0;if(n==="EXECUTE_ACTION"){const i=typeof l.action=="object"?l.action:l,r=!!l.dryRun;return!i||!i.action?(e({success:!1,error:"No valid action proposal provided."}),!0):(U.execute(i,r).then(a=>{e(a)}).catch(a=>{const c=a instanceof Error?a.message:String(a);e({success:!1,error:c,action:i.action})}),!0)}if(n==="EXTRACT_YOUTUBE_TRANSCRIPT")return q(document).then(i=>{e(i)}).catch(i=>{const r=i instanceof Error?i.message:String(i);console.error("[Madadgar Content Script] YouTube transcript failed:",r),e({videoId:l.videoId||"",title:(document==null?void 0:document.title)||"YouTube Video",hasTranscript:!1,transcriptText:"",segments:[],fallbackReason:r})}),!0;if(n==="SEEK_YOUTUBE_VIDEO"){const i=typeof l.seconds=="number"?l.seconds:0,r=document.querySelector("video");return r?(r.currentTime=i,r.paused&&r.play().catch(()=>{}),e({success:!0,currentTime:r.currentTime})):e({success:!1,error:"No video player found on current page."}),!0}return!1}let C=null;function A(){var l;typeof window>"u"||typeof chrome>"u"||!((l=chrome.runtime)!=null&&l.sendMessage)||(C&&clearTimeout(C),C=setTimeout(()=>{var t,e;try{const n=((e=(t=window.getSelection())==null?void 0:t.toString())==null?void 0:e.trim())||"";chrome.runtime.sendMessage({type:"PAGE_SELECTION_CHANGED",selection:n}).catch(()=>{})}catch{}},250))}function z(){var l;typeof chrome<"u"&&((l=chrome.runtime)!=null&&l.onMessage)&&(chrome.runtime.onMessage.addListener(j),console.log("[Madadgar Content Script] Registered Madadgar content listeners")),typeof document<"u"&&(document.addEventListener("selectionchange",A),document.addEventListener("mouseup",A))}z();export{u as BadgeOverlay,g as DOMScanner,j as handleContentScriptMessage,A as handleSelectionChange,z as initContentScript};
