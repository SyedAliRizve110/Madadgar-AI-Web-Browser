import './assets/service_worker.ts-BQ5_t9ow.js';
